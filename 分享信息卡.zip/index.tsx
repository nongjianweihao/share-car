import React, { useState } from 'react';
import ReactDOM from 'react-dom/client';

// Import all card components
import FitnessComparisonCard from './FitnessComparisonCard.tsx';
import SpecializationTrapCard from './SpecializationTrapCard.tsx';
import SensitivePeriodCard from './SensitivePeriodCard.tsx';
import CognitionShiftCard from './CognitionShiftCard.tsx';
import DoseEffectCard from './DoseEffectCard.tsx';
import StrengthCard from './StrengthCard.tsx';
import FamilyEducationCard from './FamilyEducationCard.tsx';
import SpeedCard from './SpeedCard.tsx';
import EnduranceCard from './EnduranceCard.tsx'; // Import the new card

// Data structure for all available cards, now with categories
const cards = [
    { id: 'fitness', title: '全面体能', category: '运动', component: <FitnessComparisonCard /> },
    { id: 'trap', title: '专项陷阱', category: '运动', component: <SpecializationTrapCard /> },
    { id: 'period', title: '敏感期', category: '运动', component: <SensitivePeriodCard /> },
    { id: 'cognition', title: '科学训练', category: '运动', component: <CognitionShiftCard /> },
    { id: 'strength', title: '力量素质', category: '运动', component: <StrengthCard /> },
    { id: 'speed', title: '速度素质', category: '运动', component: <SpeedCard /> },
    { id: 'endurance', title: '耐力素质', category: '运动', component: <EnduranceCard /> },
    { id: 'dose', title: 'DOSE效应', category: '学习笔记', component: <DoseEffectCard /> },
    { id: 'family-ed', title: '鼓励vs惩罚', category: '家庭教育', component: <FamilyEducationCard /> },
];

const App = () => {
    const [activeCardId, setActiveCardId] = useState(cards[0].id);

    const activeCard = cards.find(card => card.id === activeCardId);
    
    // Get a unique list of categories in the order they appear
    const categories = [...new Set(cards.map(c => c.category))];

    return (
        <div className="app-container">
            <aside className="sidebar">
                <h2 className="sidebar-title">分享卡片</h2>
                <nav className="sidebar-nav">
                    {categories.map(category => (
                        <div key={category} className="sidebar-category">
                            <h3 className="sidebar-category-title">{category}</h3>
                            {cards
                                .filter(card => card.category === category)
                                .map(card => (
                                    <button
                                        key={card.id}
                                        className={`sidebar-nav-item ${activeCardId === card.id ? 'active' : ''}`}
                                        onClick={() => setActiveCardId(card.id)}
                                    >
                                        {card.title}
                                    </button>
                                ))
                            }
                        </div>
                    ))}
                </nav>
            </aside>
            <main className="main-content">
                {activeCard ? activeCard.component : <div>请选择一个卡片</div>}
            </main>
        </div>
    );
};

const rootElement = document.getElementById('root');
if (rootElement) {
    const root = ReactDOM.createRoot(rootElement);
    root.render(<App />);
}
